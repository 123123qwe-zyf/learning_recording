#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ESP32-S3 信息采集与信号传输系统 — PC端监控上位机
=================================================
依赖安装:  pip install requests matplotlib
运行方式:  python app.py

功能:
  1. WiFi 连接 ESP32 设备，实时获取传感器状态
  2. 远程切换设备工作模式（正常 / 流传输 / 休眠）
  3. 本地 SQLite 数据库持久化存储历史数据
  4. 实时光照值折线图可视化
  5. 高速音频传输测试（浏览器下载）
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import queue
import tempfile
import threading
import time
import sqlite3
import requests

# ======================== matplotlib 初始化 ========================
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

# 中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'WenQuanYi Micro Hei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


# =========================== 全局常量 ===========================
POLL_INTERVAL     = 1.0       # 状态轮询间隔（秒）
QUEUE_CHECK_MS    = 100       # UI 消费队列间隔（毫秒）
MAX_CHART_POINTS  = 50        # 图表保留数据点数
REQUEST_TIMEOUT   = 3.0       # HTTP 请求超时（秒）
DB_FILE           = "sensor_data.db"


# =========================== 数据库管理 ===========================
class Database:
    """SQLite 本地数据库 — 持久化传感器历史数据"""

    def __init__(self, db_path: str = DB_FILE):
        self.conn: sqlite3.Connection | None = None
        try:
            self.conn = sqlite3.connect(db_path, check_same_thread=False)
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS sensor_data (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp  TEXT    DEFAULT (datetime('now','localtime')),
                    light      INTEGER,
                    mode       TEXT
                )
            ''')
            self.conn.commit()
            print("[DB] 数据库初始化成功")
        except Exception as e:
            print(f"[DB] 初始化失败: {e}")

    def insert(self, light: int, mode: str) -> None:
        """写入一条传感器记录（异常不抛出，仅打印日志）"""
        if self.conn is None:
            return
        try:
            self.conn.execute(
                "INSERT INTO sensor_data (timestamp, light, mode) "
                "VALUES (datetime('now','localtime'), ?, ?)",
                (light, mode))
            self.conn.commit()
        except Exception as e:
            print(f"[DB] 写入失败: {e}")

    def init_audio_table(self) -> None:# 初始化音频传输记录表
        """创建音频传输记录表（首次调用时）"""
        if self.conn is None:
            return
        try:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS audio_log (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp   TEXT    DEFAULT (datetime('now','localtime')),
                    file_name   TEXT,
                    file_size   INTEGER,
                    source_ip   TEXT,
                    status      TEXT
                )
            ''')
            self.conn.commit()
        except Exception as e:
            print(f"[DB] 音频表创建失败: {e}")

    def log_audio(self, file_name: str, file_size: int, source_ip: str, status: str) -> None:
        """记录音频传输日志"""
        if self.conn is None:
            return
        try:
            self.conn.execute(
                "INSERT INTO audio_log (timestamp, file_name, file_size, source_ip, status) "
                "VALUES (datetime('now','localtime'), ?, ?, ?, ?)",
                (file_name, file_size, source_ip, status))
            self.conn.commit()
            print(f"[DB] 音频传输记录已保存: {file_name} ({file_size} bytes) {status}")
        except Exception as e:
            print(f"[DB] 音频记录写入失败: {e}")

    def close(self) -> None:
        """关闭数据库连接"""
        if self.conn:
            try:
                self.conn.close()
                self.conn = None
                print("[DB] 数据库已关闭")
            except Exception as e:
                print(f"[DB] 关闭异常: {e}")


# =========================== 设备 HTTP API ===========================
class DeviceAPI:
    """封装 ESP32 HTTP Server 接口（静默吞异常，由调用方判断返回值）"""

    @staticmethod
    def get_status(ip: str) -> dict | None:
        """GET /status → 返回 JSON dict；失败返回 None"""
        try:
            r = requests.get(f"http://{ip}/status", timeout=REQUEST_TIMEOUT)
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return None

    @staticmethod
    def set_mode(ip: str, mode_name: str) -> str | None:
        """GET /mode?set=<mode_name> → 返回响应文本；失败返回 None"""
        try:
            r = requests.get(f"http://{ip}/mode?set={mode_name}", timeout=REQUEST_TIMEOUT)
            if r.status_code == 200:
                return r.text.strip()
        except Exception:
            pass
        return None

# =========================== 后台轮询线程 ===========================
class MonitorThread(threading.Thread):
    """定时轮询 /status，将结果放入线程安全队列"""

    def __init__(self, ip: str, q: queue.Queue):
        super().__init__(daemon=True)
        self.ip = ip
        self._queue = q
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        while not self._stop.is_set():
            data = DeviceAPI.get_status(self.ip)
            if data is not None:
                self._queue.put({"type": "poll", "data": data})
            else:
                self._queue.put({"type": "poll", "error": f"无法连接到 {self.ip}"})
            # 分片 sleep，保证 stop() 在 100ms 内响应
            deadline = time.time() + POLL_INTERVAL
            while time.time() < deadline and not self._stop.is_set():
                time.sleep(0.1)


# =========================== 主应用程序 ===========================
class App:
    """tkinter GUI 主程序"""

    # 颜色定义
    CLR_GREEN  = "#27ae60"
    CLR_ORANGE = "#f39c12"
    CLR_RED    = "#e74c3c"
    CLR_BG     = "#f5f6fa"
    CLR_WHITE  = "#ffffff"

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("ESP32-S3 设备监控系统")
        self.root.geometry("860x760")
        self.root.configure(bg=self.CLR_BG)
        self.root.minsize(780, 680)

        # ---- 状态 ----
        self.connected   = False
        self.device_ip   = tk.StringVar(value="172.17.91.181")
        self.monitor     = None       # MonitorThread | None
        self.dq          = queue.Queue()  # 子线程 → UI 线程数据队列

        # 设备状态显示变量
        self.var_light = tk.StringVar(value="--")
        self.var_mode  = tk.StringVar(value="--")
        self.var_wifi  = tk.StringVar(value="--")
        self.var_sleep = tk.StringVar(value="--")

        # 图表数据
        self._chart_x   = []          # 数据点序号
        self._chart_y   = []          # 光照值
        self._chart_cnt = 0

        # ---- 初始化 ----
        self.db = Database()
        self.db.init_audio_table()
        self._build_ui()
        self._consume_queue()         # 启动队列消费循环
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ================================================================
    #  UI 构建
    # ================================================================

    def _build_ui(self) -> None:
        self._build_status_bar()
        self._build_conn_panel()
        self._build_info_panel()
        self._build_ctrl_panel()
        self._build_chart_panel()

    def _build_status_bar(self) -> None:
        """顶部彩色状态栏"""
        bar = tk.Frame(self.root, bg=self.CLR_RED, height=34)
        bar.pack(fill=tk.X, padx=8, pady=(8, 3))
        bar.pack_propagate(False)

        self._bar_frame = bar
        self._bar_label = tk.Label(
            bar, text="● 未连接", fg="white", bg=self.CLR_RED,
            font=("Microsoft YaHei", 11, "bold"))
        self._bar_label.pack(side=tk.LEFT, padx=12)

        self._bar_ip = tk.Label(
            bar, text="", fg="white", bg=self.CLR_RED,
            font=("Microsoft YaHei", 9))
        self._bar_ip.pack(side=tk.RIGHT, padx=12)

    def _build_conn_panel(self) -> None:
        """连接面板"""
        f = tk.Frame(self.root, bg=self.CLR_WHITE,
                     highlightbackground="#ddd", highlightthickness=1)
        f.pack(fill=tk.X, padx=8, pady=3)
        tk.Label(f, text="设备连接", font=("Microsoft YaHei", 9, "bold"),
                 bg=self.CLR_WHITE, fg="#2c3e50").pack(anchor=tk.W, padx=10, pady=(5, 0))

        row = tk.Frame(f, bg=self.CLR_WHITE)
        row.pack(fill=tk.X, padx=10, pady=(2, 8))

        tk.Label(row, text="设备IP地址:", font=("Microsoft YaHei", 10),
                 bg=self.CLR_WHITE).pack(side=tk.LEFT)

        self._entry_ip = tk.Entry(row, textvariable=self.device_ip,
                                  width=17, font=("Consolas", 11))
        self._entry_ip.pack(side=tk.LEFT, padx=6)
        self._entry_ip.bind("<Return>", lambda _e: self._connect())

        self._btn_conn = tk.Button(row, text="连接", command=self._connect,
                                   width=7, bg="#3498db", fg="white",
                                   font=("Microsoft YaHei", 9))
        self._btn_conn.pack(side=tk.LEFT, padx=2)

        self._btn_disc = tk.Button(row, text="断开", command=self._disconnect,
                                   width=7, bg="#95a5a6", fg="white",
                                   font=("Microsoft YaHei", 9), state=tk.DISABLED)
        self._btn_disc.pack(side=tk.LEFT, padx=2)

    def _build_info_panel(self) -> None:
        """设备状态信息面板"""
        f = tk.Frame(self.root, bg=self.CLR_WHITE,
                     highlightbackground="#ddd", highlightthickness=1)
        f.pack(fill=tk.X, padx=8, pady=3)
        tk.Label(f, text="设备状态", font=("Microsoft YaHei", 9, "bold"),
                 bg=self.CLR_WHITE, fg="#2c3e50").pack(anchor=tk.W, padx=10, pady=(5, 2))

        grid = tk.Frame(f, bg=self.CLR_WHITE)
        grid.pack(padx=20, pady=(0, 8))

        items = [
            ("光照值:",   self.var_light),
            ("设备模式:", self.var_mode),
            ("WiFi状态:", self.var_wifi),
            ("休眠状态:", self.var_sleep),
        ]
        for i, (label, var) in enumerate(items):
            tk.Label(grid, text=label, font=("Microsoft YaHei", 10, "bold"),
                     bg=self.CLR_WHITE, fg="#2c3e50").grid(
                row=i, column=0, sticky=tk.W, pady=3)
            tk.Label(grid, textvariable=var, font=("Microsoft YaHei", 10),
                     bg=self.CLR_WHITE, fg="#555").grid(
                row=i, column=1, sticky=tk.W, padx=(8, 30), pady=3)

    def _build_ctrl_panel(self) -> None:
        """设备控制面板"""
        f = tk.Frame(self.root, bg=self.CLR_WHITE,
                     highlightbackground="#ddd", highlightthickness=1)
        f.pack(fill=tk.X, padx=8, pady=3)
        tk.Label(f, text="设备控制", font=("Microsoft YaHei", 9, "bold"),
                 bg=self.CLR_WHITE, fg="#2c3e50").pack(anchor=tk.W, padx=10, pady=(5, 2))

        row1 = tk.Frame(f, bg=self.CLR_WHITE)
        row1.pack(pady=(2, 4))
        self._btn_normal = tk.Button(row1, text="正常模式", width=13,
                                     command=lambda: self._set_mode("normal"),
                                     font=("Microsoft YaHei", 9),
                                     bg="#2ecc71", fg="white")
        self._btn_normal.pack(side=tk.LEFT, padx=4)
        self._btn_stream = tk.Button(row1, text="流传输模式", width=13,
                                     command=lambda: self._set_mode("stream"),
                                     font=("Microsoft YaHei", 9),
                                     bg="#3498db", fg="white")
        self._btn_stream.pack(side=tk.LEFT, padx=4)
        self._btn_sleep = tk.Button(row1, text="休眠模式", width=13,
                                    command=lambda: self._set_mode("sleep"),
                                    font=("Microsoft YaHei", 9),
                                    bg="#e67e22", fg="white")
        self._btn_sleep.pack(side=tk.LEFT, padx=4)

        self._btn_audio = tk.Button(f, text="测试音频传输", width=16,
                                    command=self._test_audio,
                                    font=("Microsoft YaHei", 9),
                                    bg="#9b59b6", fg="white")
        self._btn_audio.pack(pady=(0, 8))

        # 所有控制按钮的引用，方便批量启禁
        self._ctrl_buttons = [self._btn_normal, self._btn_stream,
                              self._btn_sleep, self._btn_audio]
        self._set_ctrl_state(tk.DISABLED)

    def _build_chart_panel(self) -> None:
        """matplotlib 折线图嵌入"""
        f = tk.Frame(self.root, bg=self.CLR_WHITE,
                     highlightbackground="#ddd", highlightthickness=1)
        f.pack(fill=tk.BOTH, expand=True, padx=8, pady=(3, 8))
        tk.Label(f, text="实时光照值趋势图（最近 50 个数据点）",
                 font=("Microsoft YaHei", 9, "bold"),
                 bg=self.CLR_WHITE, fg="#2c3e50").pack(anchor=tk.W, padx=10, pady=(5, 0))

        self._fig = Figure(figsize=(8, 3.5), dpi=100, facecolor=self.CLR_WHITE)
        self._ax = self._fig.add_subplot(111)
        self._ax.set_ylim(0, 4095)
        self._ax.set_xlim(0, MAX_CHART_POINTS)
        self._ax.set_xlabel("采样序号", fontsize=9)
        self._ax.set_ylabel("ADC值", fontsize=9)
        self._ax.set_title("实时光照值", fontsize=11, fontweight='bold')
        self._ax.grid(True, linestyle='--', alpha=0.5)
        self._ax.set_facecolor('#fafafa')

        (self._chart_line,) = self._ax.plot([], [], color='#3498db',
                                            linewidth=1.5, marker='o',
                                            markersize=3, markerfacecolor='#e74c3c')
        self._fig.tight_layout(pad=2.5)

        self._canvas = FigureCanvasTkAgg(self._fig, master=f)
        self._canvas.draw()
        self._canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=6, pady=(0, 6))

    # ================================================================
    #  连接管理
    # ================================================================

    def _connect(self) -> None:
        """点击「连接」—— 先在线程中验证设备可达，再启动监控"""
        ip = self.device_ip.get().strip()
        if not ip:
            messagebox.showwarning("输入错误", "请输入设备 IP 地址")
            return

        self._set_bar("connecting")

        def _verify():
            data = DeviceAPI.get_status(ip)
            if data is not None:
                self.dq.put({"type": "connected", "ip": ip})
            else:
                self.dq.put({"type": "connect_failed", "ip": ip})

        threading.Thread(target=_verify, daemon=True).start()

    def _on_connected(self, ip: str) -> None:
        """验证成功后由 UI 线程调用"""
        self.connected = True
        self.device_ip.set(ip)

        # 启动后台轮询
        if self.monitor:
            self.monitor.stop()
        self.monitor = MonitorThread(ip, self.dq)
        self.monitor.start()

        self._btn_conn.config(state=tk.DISABLED)
        self._btn_disc.config(state=tk.NORMAL)
        self._set_ctrl_state(tk.NORMAL)

    def _disconnect(self) -> None:
        """点击「断开」"""
        self._stop_monitor()
        self.connected = False
        self._set_bar("disconnected")
        self._btn_conn.config(state=tk.NORMAL)
        self._btn_disc.config(state=tk.DISABLED)
        self._set_ctrl_state(tk.DISABLED)

        # 清空状态显示
        for v in [self.var_light, self.var_mode, self.var_wifi, self.var_sleep]:
            v.set("--")

    def _stop_monitor(self) -> None:
        if self.monitor:
            self.monitor.stop()
            self.monitor = None

    def _set_ctrl_state(self, state: str) -> None:
        """批量设置控制按钮可用/禁用"""
        for btn in self._ctrl_buttons:
            btn.config(state=state)

    # ================================================================
    #  状态栏外观
    # ================================================================

    def _set_bar(self, status: str) -> None:
        """更新顶部彩色状态栏"""
        styles = {
            "connected":    (self.CLR_GREEN,  "● 已连接"),
            "connecting":   (self.CLR_ORANGE, "● 连接中…"),
            "disconnected": (self.CLR_RED,    "● 未连接"),
            "failed":       (self.CLR_RED,    "● 连接失败"),
        }
        color, text = styles.get(status, styles["disconnected"])
        self._bar_frame.config(bg=color)
        self._bar_label.config(text=text, bg=color)
        self._bar_ip.config(bg=color,
                            text=f"IP: {self.device_ip.get()}" if status == "connected" else "")

    # ================================================================
    #  队列消费（核心线程安全机制：子线程只写队列，UI 线程只读队列）
    # ================================================================

    def _consume_queue(self) -> None:
        """root.after 定时消费队列，更新 UI & 数据库"""
        try:
            while True:
                msg = self.dq.get_nowait()
                t = msg.get("type")

                if t == "connected":
                    self._on_connected(msg["ip"])
                    self._set_bar("connected")

                elif t == "connect_failed":
                    self._set_bar("failed")
                    self._btn_conn.config(state=tk.NORMAL)
                    messagebox.showerror("连接失败",
                                         f"无法连接到 {msg['ip']}\n"
                                         "请检查：\n"
                                         "  1. 设备是否上电运行\n"
                                         "  2. IP 地址是否正确\n"
                                         "  3. PC 与设备是否在同一网络")

                elif t == "poll":
                    if "error" in msg:
                        if self.connected:
                            self._set_bar("disconnected")
                    else:
                        self._on_poll_data(msg["data"])

                elif t == "action_result":
                    result = msg.get("result", "")
                    if result and result.startswith("OK"):
                        self._toast("操作成功")
                    else:
                        self._toast(f"操作失败: {result or '设备无响应'}")

        except queue.Empty:
            pass

        self.root.after(QUEUE_CHECK_MS, self._consume_queue)

    def _on_poll_data(self, data: dict) -> None:
        """处理一次成功的轮询数据"""
        if not self.connected:
            return

        light = int(data.get("light", 0))
        mode  = data.get("mode", "--")
        wifi  = data.get("wifi", "--")
        sleeping = "是" if data.get("sleep", False) else "否"

        self.var_light.set(str(light))
        self.var_mode.set(mode)
        self.var_wifi.set(wifi)
        self.var_sleep.set(sleeping)

        self._set_bar("connected")

        # 持久化到本地数据库
        self.db.insert(light, mode)

        # 图表滚动
        self._chart_append(light)

    # ================================================================
    #  图表
    # ================================================================

    def _chart_append(self, value: int) -> None:
        """追加数据点并刷新折线图"""
        self._chart_x.append(self._chart_cnt)
        self._chart_y.append(value)
        self._chart_cnt += 1

        if len(self._chart_x) > MAX_CHART_POINTS:
            self._chart_x = self._chart_x[-MAX_CHART_POINTS:]
            self._chart_y = self._chart_y[-MAX_CHART_POINTS:]

        self._chart_line.set_xdata(self._chart_x)
        self._chart_line.set_ydata(self._chart_y)

        if len(self._chart_x) >= 2:
            x_min = max(0, self._chart_x[-1] - MAX_CHART_POINTS + 1)
            x_max = x_min + MAX_CHART_POINTS - 1
            self._ax.set_xlim(x_min, x_max)

        self._canvas.draw_idle()

    # ================================================================
    #  设备控制
    # ================================================================

    def _set_mode(self, mode_name: str) -> None:
        """切换工作模式（后台短线程，不阻塞 UI）"""
        if not self.connected:
            return
        ip = self.device_ip.get()
        labels = {"normal": "正常模式", "stream": "流传输模式", "sleep": "休眠模式"}
        self._toast(f"正在切换到{labels.get(mode_name, mode_name)}…")

        def _do():
            result = DeviceAPI.set_mode(ip, mode_name)
            self.dq.put({"type": "action_result", "action": mode_name, "result": result})

        threading.Thread(target=_do, daemon=True).start()

    def _test_audio(self) -> None:
        """从设备下载 MP3 并用系统默认播放器播放"""
        if not self.connected:
            return
        ip = self.device_ip.get()
        url = f"http://{ip}/music.mp3"
        self._toast("正在下载音频文件…")

        def _download_and_play():
            try:
                r = requests.get(url, timeout=30)
                if r.status_code == 200:
                    content = r.content
                    content_type = r.headers.get("Content-Type", "unknown")
                    content_len = r.headers.get("Content-Length", "unknown")
                    print(f"[Audio] 响应状态: {r.status_code}")
                    print(f"[Audio] Content-Type: {content_type}")
                    print(f"[Audio] Content-Length: {content_len}")
                    print(f"[Audio] 实际下载: {len(content)} bytes")
                    print(f"[Audio] 前16字节: {content[:16].hex()}")

                    # 检查 MP3 签名
                    is_valid = False
                    if len(content) < 4:
                        print("[Audio] 错误: 文件太小!")
                    elif content[:3] == b'ID3':
                        print("[Audio] MP3 头: ID3v2 (正常)")
                        is_valid = True
                    elif content[:2] == b'\xff\xfb' or content[:2] == b'\xff\xfa':
                        print("[Audio] MP3 头: MPEG sync (正常)")
                        is_valid = True
                    else:
                        print(f"[Audio] 警告: 非标准MP3头! 内容看起来像: {content[:64]!r}")

                    # 保存到当前目录方便检查
                    save_path = os.path.join(os.getcwd(), "esp32_music_test.mp3")
                    with open(save_path, 'wb') as f:
                        f.write(content)
                    print(f"[Audio] 已保存到: {save_path}")

                    # 记录到数据库
                    status = "success" if is_valid else "invalid_format"
                    self.db.log_audio("music.mp3", len(content), ip, status)

                    # 用系统默认播放器打开
                    os.startfile(save_path)
                    self.dq.put({"type": "action_result",
                                 "result": f"OK: 下载完成 ({len(content)} bytes)，已保存到程序目录"})
                else:
                    self.dq.put({"type": "action_result",
                                 "result": f"下载失败: HTTP {r.status_code}"})
            except Exception as e:
                print(f"[Audio] 异常: {e}")
                self.dq.put({"type": "action_result",
                             "result": f"下载失败: {e}"})

        threading.Thread(target=_download_and_play, daemon=True).start()

    # ================================================================
    #  辅助
    # ================================================================

    def _toast(self, text: str, duration_ms: int = 2500) -> None:
        """在状态栏短暂显示提示文字后恢复"""
        old_text = self._bar_label.cget("text")
        self._bar_label.config(text=f"ℹ {text}")
        self.root.after(duration_ms, lambda: self._bar_label.config(text=old_text))

    def _on_close(self) -> None:
        """窗口关闭：停止线程、关闭数据库"""
        self._stop_monitor()
        self.db.close()
        self.root.destroy()


# =========================== 入口 ===========================
if __name__ == "__main__":
    App().root.mainloop()
