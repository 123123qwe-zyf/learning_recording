#ifndef __APP_CONFIG_H__
#define __APP_CONFIG_H__

#include <stdint.h>

// -------------------- WiFi 配置 --------------------
// 工作模式: WIFI_OP_STA(0) / WIFI_OP_AP(1) / WIFI_OP_APSTA(2)
#define WIFI_WORK_MODE         WIFI_OP_APSTA     // STA+AP 共存
#define WIFI_STA_SSID          "REDMI K80"
#define WIFI_STA_PASSWORD      "25802580"
#define WIFI_AP_SSID           "ESP32_S3_AP"
#define WIFI_AP_PASSWORD       "12345678"

// -------------------- HTTP Server 配置 --------------------
#define HTTP_SERVER_PORT       80

// -------------------- 光敏传感器 ADC 配置 --------------------
#define LIGHT_ADC_UNIT         ADC_UNIT_1        // ADC1
#define LIGHT_ADC_CHANNEL      ADC_CHANNEL_0      // GPIO1
#define LIGHT_ADC_ATTEN        ADC_ATTEN_DB_12   // 0~3.3V 量程
#define LIGHT_ADC_WIDTH        ADC_BITWIDTH_12   // 12-bit 精度
#define LIGHT_THRESHOLD        2000              // 光敏阈值，低于此值视为暗
#define LIGHT_FILTER_SAMPLES   5                 // 滤波采样次数

// -------------------- Flash 存储配置 --------------------
#define FLASH_PARTITION_LABEL    "storage"       // 片内 FAT 分区标签
#define LOG_MAX_SIZE_BYTES       (192 * 1024)    // 日志循环存储阈值（192KB）

// -------------------- 休眠配置 --------------------
#define SLEEP_CHECK_INTERVAL_MS   500            // 休眠期间 RTC 唤醒间隔(ms)
#define SAMPLE_INTERVAL_MS        1000           // 正常模式光敏采样间隔(ms)

// -------------------- OLED 显示配置 (I2C) --------------------
#define OLED_I2C_PORT          I2C_NUM_0
#define OLED_SDA_GPIO          4
#define OLED_SCL_GPIO          5
#define OLED_I2C_ADDR          0x3C
#define OLED_WIDTH             128
#define OLED_HEIGHT            64

// -------------------- 栈大小配置 --------------------
#define HTTP_SERVER_STACK_SIZE 8192  // 8KB
#define MAIN_TASK_STACK_SIZE   4096  // 4KB

// -------------------- Flash 嵌入 MP3 文件符号 --------------------
// 由 components/app/CMakeLists.txt 中 EMBED_FILES "music/music.mp3" 生成
// ESP-IDF 的 EMBED_FILES 只取文件名生成符号，忽略路径前缀
extern const uint8_t music_mp3_start[] asm("_binary_music_mp3_start");
extern const uint8_t music_mp3_end[]   asm("_binary_music_mp3_end");

#endif /* __APP_CONFIG_H__ */
