#ifndef __POWER_H__
#define __POWER_H__

#include <stdbool.h>    // 包含 bool 类型定义

typedef enum {
    MODE_NORMAL = 0, // 正常模式
    MODE_STREAM,     // 流式模式
    MODE_SLEEP       // 休眠模式
} work_mode_t;

void power_init(void);
bool power_is_sleeping(void);
work_mode_t power_get_mode(void);
void power_set_mode(work_mode_t mode);// 设置工作模式
const char *power_mode_str(void);// 获取工作模式字符串

#endif /* __POWER_H__ */
