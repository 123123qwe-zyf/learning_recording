#ifndef __SENSOR_H__
#define __SENSOR_H__

#include "app_config.h"
#include <stdbool.h>

void sensor_init(void);
int  sensor_read(void);
bool sensor_is_dark(void);// 检查是否为暗环境

#endif /* __SENSOR_H__ */
