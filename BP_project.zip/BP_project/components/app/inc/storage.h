#ifndef __STORAGE_H__
#define __STORAGE_H__

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* 嵌入式 MP3 信息（编译进固件 Flash 的原始数据） */
const uint8_t *storage_mp3_get_data(void);
size_t         storage_mp3_get_size(void);

/* 将嵌入式 MP3 复制到 FAT 文件系统 /sdcard/music.mp3 */
bool storage_copy_mp3_to_flash(void);

#endif /* __STORAGE_H__ */
