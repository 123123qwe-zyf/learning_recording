#include "power.h"
#include "app_config.h"
#include "sensor.h"
#include "oled.h"
#include "esp_sleep.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define TAG "POWER"// 电源管理模块标签

static work_mode_t g_mode = MODE_NORMAL;// 当前工作模式

void power_init(void)
{
    g_mode = MODE_NORMAL;
    ESP_LOGI(TAG, "Power management initialized, mode=normal");
}

bool power_is_sleeping(void)// 检查是否在休眠模式
{
    return (g_mode == MODE_SLEEP);
}

work_mode_t power_get_mode(void)// 获取当前工作模式
{
    return g_mode;
}

void power_set_mode(work_mode_t mode)
{
    g_mode = mode;
    ESP_LOGI(TAG, "Mode switched to: %s", power_mode_str());// 切换到指定模式
}

const char *power_mode_str(void)// 获取当前工作模式字符串
{
    switch (g_mode) {
        case MODE_NORMAL: return "normal";
        case MODE_STREAM: return "stream";
        case MODE_SLEEP:  return "sleep";
        default:          return "unknown";
    }
}
