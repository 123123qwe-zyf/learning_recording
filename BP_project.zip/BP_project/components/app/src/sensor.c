#include "sensor.h"
#include "adc.h"
#include "esp_log.h"

#define TAG "SENSOR"

void sensor_init(void)
{
    adc_init(LIGHT_ADC_UNIT, LIGHT_ADC_CHANNEL, LIGHT_ADC_ATTEN, LIGHT_ADC_WIDTH);
    ESP_LOGI(TAG, "Sensor initialized, threshold=%d", LIGHT_THRESHOLD);
}

int sensor_read(void)
{
    return adc_read_filtered(LIGHT_FILTER_SAMPLES);// 读取并返回滤波后的光传感器值
}

bool sensor_is_dark(void)// 检查是否为暗环境
{
    int val = adc_read_raw();// 读取原始光传感器值
    return (val >= 0) && (val <= LIGHT_THRESHOLD);// 检查是否为暗环境
}
