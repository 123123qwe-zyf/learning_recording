#include "storage.h"
#include "sd.h"
#include "app_config.h"
#include "esp_log.h"
#include <string.h>
#include <sys/stat.h>

#define TAG "STORAGE"

/* ---------- 嵌入式 MP3（编译进固件 Flash）---------- */
const uint8_t *storage_mp3_get_data(void)
{
    return music_mp3_start;
}

size_t storage_mp3_get_size(void)
{
    return (size_t)(music_mp3_end - music_mp3_start);
}

/* ---------- 将嵌入式 MP3 复制到 FAT 文件系统（首次启动执行一次）---------- */
bool storage_copy_mp3_to_flash(void)
{
    /* 挂载片内 FAT 文件系统 */
    if (!sd_card_init()) {
        ESP_LOGE(TAG, "Flash mount failed, cannot copy MP3");
        return false;
    }

    const char *path = "/sdcard/music.mp3";
    size_t expected_size = storage_mp3_get_size();

    /* 检查文件是否已存在且大小正确 */
    struct stat st;
    if (stat(path, &st) == 0 && (size_t)st.st_size == expected_size) {
        ESP_LOGI(TAG, "MP3 already on filesystem (%ld bytes)", st.st_size);
        return true;
    }

    /* 从嵌入式 Flash 数据复制到文件系统 */
    const uint8_t *data = storage_mp3_get_data();
    if (!data || expected_size == 0) {
        ESP_LOGE(TAG, "Embedded MP3 data is empty!");
        return false;
    }

    FILE *f = fopen(path, "wb");
    if (!f) {
        ESP_LOGE(TAG, "Failed to create %s", path);
        return false;
    }

    size_t written = fwrite(data, 1, expected_size, f);
    fclose(f);

    if (written != expected_size) {
        ESP_LOGE(TAG, "MP3 copy incomplete: %zu/%zu bytes", written, expected_size);
        return false;
    }

    ESP_LOGI(TAG, "MP3 copied to filesystem: %zu bytes", written);
    return true;
}
