#ifndef __ADC_H__
#define __ADC_H__

#include "esp_adc/adc_oneshot.h"

void adc_init(adc_unit_t unit, adc_channel_t channel, adc_atten_t atten, adc_bitwidth_t width);
int adc_read_raw(void);
int adc_read_filtered(int samples);

#endif /* __ADC_H__ */
