#ifndef __OLED_H__
#define __OLED_H__

#include <stdbool.h>
#include <stdint.h>

void oled_init(int sda, int scl, uint8_t addr);
void oled_clear(void);
void oled_show_string(int row, int col, const char *str);
void oled_update(int light_val, const char *mode, const char *wifi_status, const char *ip, bool sleeping);

#endif /* __OLED_H__ */
