#ifndef __OLED_FONT_H__
#define __OLED_FONT_H__

#include <stdint.h>

#define FONT_WIDTH   6
#define FONT_HEIGHT  8
#define FONT_START   32
#define FONT_COUNT   95

extern const uint8_t ascii_font6x8[FONT_COUNT][FONT_WIDTH];

#endif /* __OLED_FONT_H__ */
