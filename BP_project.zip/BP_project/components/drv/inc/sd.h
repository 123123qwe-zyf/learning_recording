/**
 * sd.h — 片内Flash FAT 文件系统接口
 *
 * 挂载路径固定为 /sdcard，底层使用 esp_vfs_fat_spiflash_mount。
 * 提供文件读写、日志追加、CSV 循环存储等业务接口。
 */

#ifndef __SD_H__
#define __SD_H__

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* 初始化片内 Flash FAT 文件系统（挂载到 /sdcard） */
bool sd_card_init(void);

/* 文件读写 */
bool   sd_read_file(const char *path, uint8_t *buf, size_t buf_size, size_t *out_len);
bool   sd_write_append(const char *path, const char *data);
bool   sd_file_exists(const char *path);
size_t sd_file_size(const char *path);
bool   sd_delete_file(const char *path);

/* 循环存储：截断文件前半部分，保留后半部分 */
bool sd_truncate_front_half(const char *path);

/* 检查日志大小并触发循环存储（超过阈值则截断） */
void sd_check_rotate_log(void);

/* 卸载文件系统 */
bool sd_deinit(void);

#endif /* __SD_H__ */
