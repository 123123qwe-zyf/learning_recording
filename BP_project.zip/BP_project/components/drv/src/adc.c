#include "adc.h"
#include "esp_log.h"

#define TAG "ADC"//ADC驱动标签

static adc_oneshot_unit_handle_t g_adc_handle = NULL;//ADC句柄
static adc_channel_t g_adc_channel;//ADC通道

void adc_init(adc_unit_t unit, adc_channel_t channel, adc_atten_t atten, adc_bitwidth_t width)
{
    g_adc_channel = channel;
    adc_oneshot_unit_init_cfg_t unit_cfg = {
        .unit_id = unit,//ADC单元ID
    };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&unit_cfg, &g_adc_handle));//创建ADC句柄

    adc_oneshot_chan_cfg_t chan_cfg = {
        .atten = atten,//ADC通道增益
        .bitwidth = width,//ADC通道位宽
    };//ADC通道配置
    ESP_ERROR_CHECK(adc_oneshot_config_channel(g_adc_handle, channel, &chan_cfg));//配置ADC通道
    ESP_LOGI(TAG, "ADC initialized (unit=%d, ch=%d)", unit, channel);//日志输出
}
int adc_read_raw(void)
{
    int raw = 0;//原始ADC值
    esp_err_t ret = adc_oneshot_read(g_adc_handle, g_adc_channel, &raw);//读取ADC值
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "ADC read failed: %s", esp_err_to_name(ret));
        return -1;
    }
    return raw;
}

int adc_read_filtered(int samples)// 读取并返回滤波后的ADC值
{
    if (samples <= 0) 
    {
        return adc_read_raw();// 采样次数小于等于0时，返回原始值
    }
    int sum = 0, valid = 0;
    for (int i = 0; i < samples; i++)
    {
        int v = adc_read_raw();
        if (v >= 0)
        { 
            sum += v; 
            valid++;// 有效采样次数 
        }
    }
    return (valid > 0) ? (sum / valid) : -1;// 返回滤波后的值
}
