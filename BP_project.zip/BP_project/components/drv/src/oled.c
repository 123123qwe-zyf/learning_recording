#include "oled.h"
#include "oled_font.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include <string.h>
#include <stdio.h>

#define TAG "OLED"

#define SSD1306_CMD      0x00// 命令字节前缀
#define SSD1306_DATA     0x40// 数据字节前缀

static int g_sda, g_scl;
static uint8_t g_i2c_addr;
static bool g_inited = false;

static esp_err_t oled_write_cmd(uint8_t cmd)// 发送命令字节
{
    uint8_t buf[2] = {SSD1306_CMD, cmd};
    return i2c_master_write_to_device(I2C_NUM_0, g_i2c_addr, buf, 2, pdMS_TO_TICKS(100));// 发送命令字节
}

static esp_err_t oled_write_data(uint8_t data)// 发送数据字节
{
    uint8_t buf[2] = {SSD1306_DATA, data};
    return i2c_master_write_to_device(I2C_NUM_0, g_i2c_addr, buf, 2, pdMS_TO_TICKS(100));
}

void oled_init(int sda, int scl, uint8_t addr)
{
    g_sda = sda; g_scl = scl; g_i2c_addr = addr;

    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,// 主模式
        .sda_io_num = sda,// SDA引脚
        .scl_io_num = scl,// SCL引脚
        .sda_pullup_en = GPIO_PULLUP_ENABLE,// 上拉电阻
        .scl_pullup_en = GPIO_PULLUP_ENABLE,// 上拉电阻
        .master.clk_speed = 400000,// 400kHz
    };
    ESP_ERROR_CHECK(i2c_param_config(I2C_NUM_0, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(I2C_NUM_0, I2C_MODE_MASTER, 0, 0, 0));

    // SSD1306 初始化序列
    oled_write_cmd(0xAE); // display off
    oled_write_cmd(0xD5); oled_write_cmd(0x80); // set osc clock
    oled_write_cmd(0xA8); oled_write_cmd(0x3F); 
    oled_write_cmd(0xD3); oled_write_cmd(0x00); // display offset
    oled_write_cmd(0x40); // start line
    oled_write_cmd(0x8D); oled_write_cmd(0x14); // charge pump
    oled_write_cmd(0x20); oled_write_cmd(0x00); // memory mode: horizontal
    oled_write_cmd(0xA1); // segment remap
    oled_write_cmd(0xC8); // com scan remap
    oled_write_cmd(0xDA); oled_write_cmd(0x12); // com pins
    oled_write_cmd(0x81); oled_write_cmd(0xCF); // contrast
    oled_write_cmd(0xD9); oled_write_cmd(0xF1); // pre-charge
    oled_write_cmd(0xDB); oled_write_cmd(0x40); // vcom detect
    oled_write_cmd(0xA4); // resume display
    oled_write_cmd(0xA6); // normal display
    oled_write_cmd(0xAF); // display on

    g_inited = true;// 初始化完成
    oled_clear();
    ESP_LOGI(TAG, "OLED initialized (SDA=%d, SCL=%d)", sda, scl);
}

void oled_clear(void)
{
    if (!g_inited) return;
    for (int page = 0; page < 8; page++) {// 清除所有页
        oled_write_cmd(0xB0 + page);// 页地址
        oled_write_cmd(0x00);// 列低 4 位
        oled_write_cmd(0x10);// 列高 4 位
        for (int col = 0; col < 128; col++) {
            oled_write_data(0x00);
        }
    }
}

void oled_show_string(int row, int col, const char *str)
{
    if (!g_inited || row < 0 || row > 7 || !str) return;

    oled_write_cmd(0xB0 + row);          // 页地址
    oled_write_cmd(0x00 + (col & 0x0F)); // 列低 4 位
    oled_write_cmd(0x10 + (col >> 4));   // 列高 4 位

    while (*str) {
        uint8_t c = (uint8_t)(*str);
        int idx = c - FONT_START;
        if (idx >= 0 && idx < FONT_COUNT) {
            for (int i = 0; i < FONT_WIDTH; i++) {
                oled_write_data(ascii_font6x8[idx][i]);
            }
        } else {
            for (int i = 0; i < FONT_WIDTH; i++) {
                oled_write_data(0x00);
            }
        }
        str++;
    }
}

void oled_update(int light_val, const char *mode, const char *wifi_status, const char *ip, bool sleeping)
{
    if (!g_inited) return;
    oled_clear();
    char buf[22];
    snprintf(buf, sizeof(buf), "Light:%d", light_val);// 显示光照值
    oled_show_string(0, 0, buf);
    snprintf(buf, sizeof(buf), "IP:%s", ip);
    oled_show_string(1, 0, buf);
    snprintf(buf, sizeof(buf), "Mode:%s", mode);
    oled_show_string(3, 0, buf);
    snprintf(buf, sizeof(buf), "WiFi:%s", wifi_status);
    oled_show_string(5, 0, buf);
    snprintf(buf, sizeof(buf), "Sleep:%s", sleeping ? "YES" : "NO");
    oled_show_string(7, 0, buf);
}
