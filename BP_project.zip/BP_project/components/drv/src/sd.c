/**
 * sd.c — 片内Flash FAT 文件系统（替换原 SPI SD 卡逻辑）
 *
 * 硬件层面已移除外部 SPI SD 模块，所有存储操作改为 ESP32 片内 Flash。
 * 挂载路径固定为 /sdcard，底层使用 esp_vfs_fat_spiflash_mount。
 *
 * 保留原有业务逻辑：文件读写、日志追加、CSV 循环存储。
 * 新增 FreeRTOS 互斥锁，防止多任务并发写。
 */

#include "sd.h"
#include "esp_vfs_fat.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>

#define TAG "SD"

/* ---------- Flash 分区配置 ---------- */
#define SD_MOUNT_POINT      "/sdcard"
#define SD_PARTITION_LABEL  "storage"

/* ---------- 循环存储阈值 ---------- */
#define LOG_MAX_SIZE_BYTES  (192 * 1024)  // 192KB，适配 2MB Flash 小分区

/* ---------- 全局状态 ---------- */
static wl_handle_t      g_wl_handle = WL_INVALID_HANDLE;
static SemaphoreHandle_t g_mutex    = NULL;
static bool              g_mounted  = false;

/* ---------- 底层挂载（片内 Flash FAT）---------- */

bool sd_card_init(void)
{
    if (g_mounted) return true;

    /* 创建文件操作互斥锁（首次调用时） */
    if (!g_mutex) {
        g_mutex = xSemaphoreCreateMutex();
        if (!g_mutex) {
            ESP_LOGE(TAG, "Failed to create mutex");
            return false;
        }
    }

    /* 挂载配置：首次自动格式化 */
    esp_vfs_fat_mount_config_t mount_cfg = {
        .format_if_mount_failed = true,
        .max_files              = 5,
        .allocation_unit_size   = CONFIG_WL_SECTOR_SIZE,
    };

    esp_err_t ret = esp_vfs_fat_spiflash_mount_rw_wl(
        SD_MOUNT_POINT,
        SD_PARTITION_LABEL,
        &mount_cfg,
        &g_wl_handle);

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Flash FAT mount failed: %s", esp_err_to_name(ret));
        ESP_LOGE(TAG, "Check partition table: need 'storage,data,fat' partition");
        return false;
    }

    g_mounted = true;
    ESP_LOGI(TAG, "Internal flash FAT mounted at %s", SD_MOUNT_POINT);
    return true;
}


/* ================================================================
 *  以下为业务逻辑函数，接口与原 sd.h 兼容
 *  所有文件操作均加互斥锁保护
 * ================================================================ */

bool sd_read_file(const char *path, uint8_t *buf, size_t buf_size, size_t *out_len)
{
    if (!g_mounted || !buf || !out_len) return false;
    if (xSemaphoreTake(g_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) return false;

    FILE *f = fopen(path, "rb");
    if (!f) {
        xSemaphoreGive(g_mutex);
        ESP_LOGE(TAG, "Failed to open %s for reading", path);
        return false;
    }
    *out_len = fread(buf, 1, buf_size, f);
    fclose(f);
    xSemaphoreGive(g_mutex);
    return true;
}


bool sd_write_append(const char *path, const char *data)
{
    if (!g_mounted || !data) return false;
    if (xSemaphoreTake(g_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) return false;

    FILE *f = fopen(path, "a");
    if (!f) {
        xSemaphoreGive(g_mutex);
        ESP_LOGE(TAG, "Failed to open %s for append", path);
        return false;
    }
    fprintf(f, "%s", data);
    fclose(f);
    xSemaphoreGive(g_mutex);
    return true;
}


bool sd_file_exists(const char *path)
{
    if (!g_mounted) return false;
    struct stat st;
    return stat(path, &st) == 0;
}


size_t sd_file_size(const char *path)
{
    if (!g_mounted) return 0;
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    return (size_t)st.st_size;
}


bool sd_delete_file(const char *path)
{
    if (!g_mounted) return false;
    if (unlink(path) != 0) {
        ESP_LOGE(TAG, "Failed to delete %s", path);
        return false;
    }
    return true;
}


/**
 * 循环存储：截断文件前半部分，保留后半部分数据
 * 用于日志文件超过大小阈值时触发
 */
bool sd_truncate_front_half(const char *path)// 截断文件前半部分，保留后半部分数据
{
    if (!g_mounted) return false;
    if (xSemaphoreTake(g_mutex, pdMS_TO_TICKS(2000)) != pdTRUE) return false;

    size_t total = sd_file_size(path);// 获取文件大小
    if (total == 0) {
        xSemaphoreGive(g_mutex);
        return true;  // 空文件无需处理
    }

    size_t half = total / 2;
    char *buf = (char *)malloc(half);
    if (!buf) {
        xSemaphoreGive(g_mutex);
        ESP_LOGE(TAG, "Truncate: malloc(%d) failed", (int)half);
        return false;
    }

    /* 读取后半部分 */
    FILE *f = fopen(path, "rb");
    if (!f) {
        free(buf);
        xSemaphoreGive(g_mutex);
        return false;
    }
    fseek(f, (long)half, SEEK_SET);
    size_t read_len = fread(buf, 1, half, f);
    fclose(f);

    /* 对齐到换行符，避免截断行 */
    char *line_start = (char *)memchr(buf, '\n', read_len);
    if (line_start) {
        size_t offset = (size_t)(line_start - buf) + 1;
        read_len -= offset;
        memmove(buf, line_start + 1, read_len);
    }

    /* 重写文件：表头 + 保留数据 */
    f = fopen(path, "wb");
    if (!f) {
        free(buf);
        xSemaphoreGive(g_mutex);
        return false;
    }
    fprintf(f, "timestamp_ms,event_type,light_value\n");
    fwrite(buf, 1, read_len, f);
    fclose(f);
    free(buf);

    ESP_LOGI(TAG, "Truncated %s: removed first half, header restored (%d bytes kept)",
             path, (int)read_len);
    xSemaphoreGive(g_mutex);
    return true;
}


/**
 * 检查日志大小并在超限时触发循环存储
 */
void sd_check_rotate_log(void)
{
    if (!g_mounted) return;

    const char *log_path = SD_MOUNT_POINT "/log.csv";
    size_t size = sd_file_size(log_path);
    if (size > LOG_MAX_SIZE_BYTES) {
        ESP_LOGI(TAG, "Log size %d > %d, rotating...",
                 (int)size, (int)LOG_MAX_SIZE_BYTES);
        sd_truncate_front_half(log_path);
    }
}


bool sd_deinit(void)
{
    if (!g_mounted) return true;

    /* 等待正在进行的文件操作完成 */
    if (g_mutex) {
        xSemaphoreTake(g_mutex, pdMS_TO_TICKS(3000));
    }

    esp_err_t ret = esp_vfs_fat_spiflash_unmount_rw_wl(SD_MOUNT_POINT, g_wl_handle);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Unmount warning: %s", esp_err_to_name(ret));
    }
    g_wl_handle = WL_INVALID_HANDLE;
    g_mounted = false;

    if (g_mutex) {
        xSemaphoreGive(g_mutex);
    }

    ESP_LOGI(TAG, "Flash FAT unmounted from %s", SD_MOUNT_POINT);
    return true;
}
