#ifndef __TCP_H__
#define __TCP_H__

void http_server_start(void);
void http_server_stop(void);

#endif /* __TCP_H__ */
