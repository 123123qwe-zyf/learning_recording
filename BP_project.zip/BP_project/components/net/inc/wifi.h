#ifndef __WIFI_H__
#define __WIFI_H__

#include "esp_err.h"
#include <stdbool.h>

typedef enum {
    WIFI_OP_STA = 0,
    WIFI_OP_AP,
    WIFI_OP_APSTA
} wifi_op_mode_t;

typedef enum {
    WIFI_DISCONNECTED = 0,
    WIFI_CONNECTING,
    WIFI_CONNECTED
} wifi_status_t;

void wifi_init(wifi_op_mode_t mode, const char *sta_ssid, const char *sta_pwd,
               const char *ap_ssid, const char *ap_pwd);
void wifi_stop(void);
wifi_status_t wifi_get_status(void);
const char *wifi_status_str(void);
const char *wifi_get_ip_str(void);

#endif /* __WIFI_H__ */
