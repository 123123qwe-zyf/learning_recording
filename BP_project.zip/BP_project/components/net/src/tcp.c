#include "tcp.h"
#include "power.h"
#include "sensor.h"
#include "storage.h"
#include "wifi.h"
#include "app_config.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


#define TAG "HTTP"

static httpd_handle_t g_server = NULL;// HTTP服务器句柄

/* ---------- /status ---------- */
static esp_err_t status_handler(httpd_req_t *req)// 状态处理函数
{
    int light = sensor_read();// 读取光照值
    const char *mode = power_mode_str();// 获取当前模式
    const char *wifi = wifi_status_str();// 获取WiFi状态
    bool sleeping = power_is_sleeping();// 获取是否睡眠状态

    char json[256];// JSON字符串缓冲区
    snprintf(json, sizeof(json),
        "{\"light\":%d,\"mode\":\"%s\",\"wifi\":\"%s\",\"sleep\":%s}",
        light, mode, wifi, sleeping ? "true" : "false");// 构建JSON字符串

    httpd_resp_set_type(req, "application/json");// 设置响应类型为JSON
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");// 允许所有来源访问
    httpd_resp_send(req, json, strlen(json));// 发送JSON字符串
    return ESP_OK;
}

static esp_err_t mode_handler(httpd_req_t *req)// 模式处理函数
{
    char buf[32] = {0};
    size_t buf_len = httpd_req_get_url_query_len(req) + 1;// 获取URL查询参数长度
    if (buf_len > sizeof(buf)) buf_len = sizeof(buf);

    if (httpd_req_get_url_query_str(req, buf, buf_len) != ESP_OK) {
        httpd_resp_send_404(req);// 发送404错误响应
        return ESP_FAIL;
    }

    char value[16] = {0};
    if (httpd_query_key_value(buf, "set", value, sizeof(value)) != ESP_OK)// 解析查询参数
    {
        httpd_resp_send_404(req);
        return ESP_FAIL;
    }

    httpd_resp_set_type(req, "text/plain");// 设置响应类型为文本
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");// 允许所有来源访问

    if (strcmp(value, "normal") == 0) {
        power_set_mode(MODE_NORMAL);
        httpd_resp_sendstr(req, "OK: mode=normal");// 发送成功响应
        ESP_LOGI(TAG, "HTTP: mode set to normal");// 记录日志
    } else if (strcmp(value, "stream") == 0) {
        power_set_mode(MODE_STREAM);
        httpd_resp_sendstr(req, "OK: mode=stream");// 发送成功响应
        ESP_LOGI(TAG, "HTTP: mode set to stream");// 记录日志
    } else if (strcmp(value, "sleep") == 0) {
        power_set_mode(MODE_SLEEP);
        httpd_resp_sendstr(req, "OK: mode=sleep");
        ESP_LOGI(TAG, "HTTP: mode set to sleep");
    } else {
        httpd_resp_send_404(req);
        return ESP_FAIL;
    }
    return ESP_OK;
}

/* ---------- /music.mp3 ---------- */
#define MP3_FS_PATH     "/sdcard/music.mp3"// MP3文件路径
#define MP3_BUF_SIZE    4096               // MP3缓冲区大小

static esp_err_t mp3_handler(httpd_req_t *req)// MP3处理函数
{
    /* 从 FAT 文件系统读取 MP3 文件（启动时已从嵌入式 Flash 复制） */
    FILE *f = fopen(MP3_FS_PATH, "rb");// 打开文件
    if (!f) {
        ESP_LOGE(TAG, "Failed to open %s", MP3_FS_PATH);
        httpd_resp_set_type(req, "text/plain");// 设置响应类型为文本
        httpd_resp_send_404(req);
        return ESP_FAIL;
    }

    /* 获取文件大小 */
    fseek(f, 0, SEEK_END);// 移动文件指针到末尾
    long file_size = ftell(f);// 获取文件指针位置（文件大小）
    fseek(f, 0, SEEK_SET);// 移动文件指针到开头

    if (file_size <= 0) {
        fclose(f);
        httpd_resp_send_404(req);
        return ESP_FAIL;
    }

    /* 设置 HTTP 响应头 */
    httpd_resp_set_type(req, "audio/mpeg");// 设置响应类型为MP3
    httpd_resp_set_hdr(req, "Content-Disposition", "attachment; filename=\"music.mp3\"");// 设置响应头为附件下载
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");// 允许所有来源访问

    char len_str[32];
    snprintf(len_str, sizeof(len_str), "%ld", file_size);// 构建文件大小字符串
    httpd_resp_set_hdr(req, "Content-Length", len_str);// 设置响应头为文件大小

    /* 分块读取并发送（Content-Length 已设，无 chunked 编码） */
    char buf[MP3_BUF_SIZE];
    size_t n;
    long sent = 0;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) {
        if (httpd_resp_send_chunk(req, buf, (ssize_t)n) != ESP_OK) {
            ESP_LOGW(TAG, "Client disconnected during MP3 send");
            break;
        }
        sent += (long)n;
    }
    httpd_resp_send_chunk(req, NULL, 0);
    fclose(f);

    ESP_LOGI(TAG, "MP3 served: %ld bytes from %s", sent, MP3_FS_PATH);
    return ESP_OK;
}

/* ---------- 注册路由 ---------- */
static void register_routes(httpd_handle_t server)
{
    httpd_uri_t uri_status = {
        .uri       = "/status",
        .method    = HTTP_GET,
        .handler   = status_handler,
    };
    httpd_register_uri_handler(server, &uri_status);

    httpd_uri_t uri_mode =
    {
        .uri       = "/mode",// 模式路由
        .method    = HTTP_GET,// GET方法
        .handler   = mode_handler,// 模式处理函数
    };
    httpd_register_uri_handler(server, &uri_mode);

    httpd_uri_t uri_mp3 = {
        .uri       = "/music.mp3",
        .method    = HTTP_GET,
        .handler   = mp3_handler,
    };
    httpd_register_uri_handler(server, &uri_mp3);
}

/* ---------- 启动/停止 HTTP Server ---------- */
void http_server_start(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port = HTTP_SERVER_PORT;
    cfg.stack_size  = HTTP_SERVER_STACK_SIZE;
    cfg.max_uri_handlers = 8;

    if (httpd_start(&g_server, &cfg) == ESP_OK) {
        register_routes(g_server);
        ESP_LOGI(TAG, "HTTP server started on port %d", HTTP_SERVER_PORT);
    } else {
        ESP_LOGE(TAG, "Failed to start HTTP server");
    }
}

void http_server_stop(void)// 停止HTTP服务器
{
    if (g_server) {
        httpd_stop(g_server);
        g_server = NULL;// 重置服务器句柄
        ESP_LOGI(TAG, "HTTP server stopped");
    }
}
