#include "wifi.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/timers.h"
#include <string.h>

#define TAG "WIFI"

/* ---------- 重连策略 ---------- */
#define WIFI_MAX_RETRY           8      // 连续重试上限
#define WIFI_RETRY_BASE_MS       500    // 首次重试延迟
#define WIFI_RETRY_MAX_MS        30000  // 最大重试延迟 (退避上限 30s)
#define WIFI_RSSI_THRESHOLD      -85    // 手机热点信号波动大，放宽阈值避免误判

static wifi_status_t g_wifi_status = WIFI_DISCONNECTED;
static char g_ip_str[16] = "0.0.0.0";// 存储当前IP地址
static EventGroupHandle_t g_wifi_evt = NULL;// 事件组句柄
static TimerHandle_t g_reconnect_timer = NULL;
static int g_retry_count = 0;// 重连次数
static bool g_netif_inited = false;// 网络接口是否初始化
static bool g_sta_netif = false;// STA网络接口是否初始化
static bool g_ap_netif = false;// AP网络接口是否初始化
static bool g_handlers_registered = false;// 是否注册路由处理函数
static bool g_wifi_driver_inited = false;// 是否初始化WiFi驱动
#define WIFI_CONNECTED_BIT BIT0// 连接状态位掩码

static void nvs_init(void)// 初始化NVS存储
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();// 擦除NVS存储
        ret = nvs_flash_init();
    }
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS init failed: %s", esp_err_to_name(ret));
    }
}

/* ---------- 重连定时器回调（实现指数退避）---------- */
static void reconnect_timer_cb(TimerHandle_t pxTimer)
{
    /* 重连前先检查 AP 信号强度 */
    wifi_ap_record_t ap_info;// AP信息结构体
    if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {// 获取当前连接的AP信息
        ESP_LOGI(TAG, "AP rssi=%d, retry=%d/%d", ap_info.rssi,
                 g_retry_count, WIFI_MAX_RETRY);// 打印AP信号强度和重试次数
        if (ap_info.rssi < WIFI_RSSI_THRESHOLD) {// 信号强度低于阈值，跳过重连
            ESP_LOGW(TAG, "Signal too weak (%d), skip retry", ap_info.rssi);
            g_retry_count++;
            if (g_retry_count < WIFI_MAX_RETRY) {// 重试次数未超过上限
                uint32_t delay = WIFI_RETRY_BASE_MS * (1 << g_retry_count);// 计算重试延迟
                if (delay > WIFI_RETRY_MAX_MS) delay = WIFI_RETRY_MAX_MS;// 重试延迟不能超过最大值
                ESP_LOGI(TAG, "Next retry in %lu ms", delay);   
                xTimerChangePeriod(g_reconnect_timer, pdMS_TO_TICKS(delay), 0);// 更新定时器周期
                xTimerStart(g_reconnect_timer, 0);// 启动定时器
            } else {
                /* STA 重试耗尽：如有 AP 则回退为 AP 模式，保持设备可访问 */
                ESP_LOGW(TAG, "STA retries exhausted, AP fallback only");
                if (g_ap_netif) {// 有AP网络接口，回退为AP模式
                    strcpy(g_ip_str, "192.168.4.1");
                    g_wifi_status = WIFI_CONNECTED;  // AP 仍在工作
                } else {
                    g_wifi_status = WIFI_DISCONNECTED;
                }
            }
            return;
        }
    }
    ESP_LOGI(TAG, "Attempting reconnect (%d/%d)...", g_retry_count + 1, WIFI_MAX_RETRY);// 打印重连次数
    esp_wifi_connect();// 重连 WiFi
}



static void event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)// 处理WiFi事件
{
    if (base == WIFI_EVENT) {
        if (id == WIFI_EVENT_STA_START) {
            g_wifi_status = WIFI_CONNECTING;
            g_retry_count = 0;
            esp_wifi_connect();
        } else if (id == WIFI_EVENT_STA_DISCONNECTED) {
            wifi_event_sta_disconnected_t *evt =
                (wifi_event_sta_disconnected_t *)data;
            g_wifi_status = WIFI_DISCONNECTED;
            strcpy(g_ip_str, "0.0.0.0");

            ESP_LOGW(TAG, "Disconnected, reason=%d, retry=%d/%d",
                     evt->reason, g_retry_count, WIFI_MAX_RETRY);

            /* 指数退避重连，避免"闪断-狂连"死循环 */
            if (g_retry_count < WIFI_MAX_RETRY) {
                uint32_t delay = WIFI_RETRY_BASE_MS * (1 << g_retry_count);
                if (delay > WIFI_RETRY_MAX_MS) delay = WIFI_RETRY_MAX_MS;
                g_retry_count++;
                ESP_LOGI(TAG, "Reconnect in %lu ms", delay);
                xTimerChangePeriod(g_reconnect_timer, pdMS_TO_TICKS(delay), 0);
                xTimerStart(g_reconnect_timer, 0);
            } else {
                /* STA 重试耗尽：AP 模式回退，保持设备可访问 */
                ESP_LOGW(TAG, "STA max retries (%d) reached", WIFI_MAX_RETRY);
                if (g_ap_netif) {
                    strcpy(g_ip_str, "192.168.4.1");
                    g_wifi_status = WIFI_CONNECTED;
                    ESP_LOGI(TAG, "AP fallback: %s", g_ip_str);
                }
            }
        } else if (id == WIFI_EVENT_STA_CONNECTED) {
            /* 连接成功后清零重试计数 */
            g_retry_count = 0;
            g_wifi_status = WIFI_CONNECTING; // 等待 DHCP
            ESP_LOGI(TAG, "STA connected, waiting for IP...");
        } else if (id == WIFI_EVENT_AP_STACONNECTED) {
            ESP_LOGI(TAG, "Client connected to AP");
        } else if (id == WIFI_EVENT_AP_STADISCONNECTED) {
            ESP_LOGI(TAG, "Client disconnected from AP");
        }
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *evt = (ip_event_got_ip_t *)data;
        snprintf(g_ip_str, sizeof(g_ip_str), IPSTR, IP2STR(&evt->ip_info.ip));
        g_wifi_status = WIFI_CONNECTED;
        g_retry_count = 0;  // 彻底稳定，清零
        ESP_LOGI(TAG, "WiFi connected, IP: %s", g_ip_str);
        xEventGroupSetBits(g_wifi_evt, WIFI_CONNECTED_BIT);
    }
}

void wifi_init(wifi_op_mode_t mode, const char *sta_ssid, const char *sta_pwd,
               const char *ap_ssid, const char *ap_pwd)
{
    nvs_init();

    bool need_sta = (mode == WIFI_OP_STA || mode == WIFI_OP_APSTA);
    bool need_ap  = (mode == WIFI_OP_AP || mode == WIFI_OP_APSTA);

    /* ---------- 系统初始化 ---------- */
    if (!g_netif_inited) {
        ESP_ERROR_CHECK(esp_netif_init());
        ESP_ERROR_CHECK(esp_event_loop_create_default());
        g_netif_inited = true;
    }

    /* 事件组 */
    if (!g_wifi_evt) {
        g_wifi_evt = xEventGroupCreate();
    }
    xEventGroupClearBits(g_wifi_evt, WIFI_CONNECTED_BIT);

    /* 重连定时器（一次性，动态改周期） */
    if (!g_reconnect_timer) {
        g_reconnect_timer = xTimerCreate("wifi_retry",
                                         pdMS_TO_TICKS(WIFI_RETRY_BASE_MS),
                                         pdFALSE,   // 一次性，不自重载
                                         NULL,
                                         reconnect_timer_cb);
    }

    /* 按需创建 netif */
    if (need_sta && !g_sta_netif) {
        esp_netif_create_default_wifi_sta();
        g_sta_netif = true;
    }
    if (need_ap && !g_ap_netif) {
        esp_netif_create_default_wifi_ap();
        g_ap_netif = true;
    }

    /* 初始化 WiFi 驱动 */
    if (!g_wifi_driver_inited) {
        wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
        ESP_ERROR_CHECK(esp_wifi_init(&cfg));
        g_wifi_driver_inited = true;
    }

    /* 事件处理器（只注册一次） */
    if (!g_handlers_registered) {
        ESP_ERROR_CHECK(esp_event_handler_instance_register(
            WIFI_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL, NULL));
        ESP_ERROR_CHECK(esp_event_handler_instance_register(
            IP_EVENT, IP_EVENT_STA_GOT_IP, &event_handler, NULL, NULL));
        g_handlers_registered = true;
    }

    /* 设置 WiFi 模式 */
    wifi_mode_t wifi_mode;
    if (mode == WIFI_OP_APSTA) {
        wifi_mode = WIFI_MODE_APSTA;
    } else if (mode == WIFI_OP_STA) {
        wifi_mode = WIFI_MODE_STA;
    } else {
        wifi_mode = WIFI_MODE_AP;
    }
    ESP_ERROR_CHECK(esp_wifi_set_mode(wifi_mode));

    /* ========== STA 配置 + 稳定性参数 ========== */
    if (need_sta) {
        wifi_config_t sta_cfg = {
            .sta = {
                /* 扫描方法：全信道扫描，找到最强信号 */
                .scan_method = WIFI_ALL_CHANNEL_SCAN,
                /* 排序：按信号强度，选最强的 */
                .sort_method = WIFI_CONNECT_AP_BY_SIGNAL,
                /* 最小 RSSI：低于此值的 AP 直接跳过 */
                .threshold.rssi = WIFI_RSSI_THRESHOLD,
                /* 认证模式阈值：不限制 */
                .threshold.authmode = WIFI_AUTH_OPEN,
            },
        };
        strncpy((char *)sta_cfg.sta.ssid, sta_ssid, sizeof(sta_cfg.sta.ssid) - 1);
        strncpy((char *)sta_cfg.sta.password, sta_pwd, sizeof(sta_cfg.sta.password) - 1);
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &sta_cfg));

        /* --- 协议参数，对手机热点稳定性至关重要 --- */

        /* 1. 省电模式：设为 WIFI_PS_NONE，避免手机热点因省电策略踢设备 */
        ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_NONE));

        /* 2. 协议模式：限定 802.11b/g/n，手机热点兼容性最好 */
        ESP_ERROR_CHECK(esp_wifi_set_protocol(WIFI_IF_STA,
            WIFI_PROTOCOL_11B | WIFI_PROTOCOL_11G | WIFI_PROTOCOL_11N));

        /* 3. 带宽：20MHz，穿墙能力和稳定性优于 40MHz */
        ESP_ERROR_CHECK(esp_wifi_set_bandwidth(WIFI_IF_STA, WIFI_BW_HT20));

        /* 4. 连接超时延长到 30s（手机热点偶尔会慢） */
        esp_wifi_set_config(WIFI_IF_STA, &sta_cfg); // 确保 config 已写入
        // 注意: 连接超时通过 scan_method 和底层协议栈一起控制

        ESP_LOGI(TAG, "STA configured: SSID=%s, scan=all, sort=signal, rssi_min=%d",
                 sta_ssid, WIFI_RSSI_THRESHOLD);
    }

    /* ========== AP 配置 ========== */
    if (need_ap) {
        wifi_config_t ap_cfg = {
            .ap = {
                .max_connection = 1,
                .authmode = WIFI_AUTH_WPA2_PSK,
            },
        };
        strncpy((char *)ap_cfg.ap.ssid, ap_ssid, sizeof(ap_cfg.ap.ssid) - 1);
        strncpy((char *)ap_cfg.ap.password, ap_pwd, sizeof(ap_cfg.ap.password) - 1);
        ap_cfg.ap.ssid_len = strlen(ap_ssid);
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap_cfg));
        ESP_LOGI(TAG, "AP configured: SSID=%s", ap_ssid);
    }

    /* 启动 WiFi */
    g_retry_count = 0;
    ESP_ERROR_CHECK(esp_wifi_start());

    /* --- 稳定性与可发现性参数（必须在 esp_wifi_start 之后设置）--- */

    /* 固定信道 6：兼容性最好，避免自动扫描导致的信道跳变 */
    if (need_ap) {
        esp_wifi_set_channel(6, WIFI_SECOND_CHAN_NONE);
    }

    /* 最大发射功率：提高 AP 可发现范围 (21dBm = 84 单位) */
    esp_wifi_set_max_tx_power(84);

    /* AP 协议：802.11b/g/n，最大兼容性 */
    if (need_ap) {
        esp_wifi_set_protocol(WIFI_IF_AP,
            WIFI_PROTOCOL_11B | WIFI_PROTOCOL_11G | WIFI_PROTOCOL_11N);
        esp_wifi_set_bandwidth(WIFI_IF_AP, WIFI_BW_HT20);
    }

    /* ========== 等待 STA 连接（延长超时） ========== */
    if (need_sta) {
        g_wifi_status = WIFI_CONNECTING;
        strcpy(g_ip_str, "0.0.0.0");
        /* 首次连接给 30s（手机热点 DHCP 可能慢） */
        EventBits_t bits = xEventGroupWaitBits(g_wifi_evt, WIFI_CONNECTED_BIT,
                                               pdFALSE, pdTRUE, pdMS_TO_TICKS(30000));
        if (bits & WIFI_CONNECTED_BIT) {
            ESP_LOGI(TAG, "STA connected successfully, IP: %s", g_ip_str);
        } else {
            ESP_LOGW(TAG, "STA connection timeout (30s)");
            if (need_ap) {
                strcpy(g_ip_str, "192.168.4.1");
                g_wifi_status = WIFI_CONNECTED;
                ESP_LOGI(TAG, "AP available: SSID=%s, IP=%s", ap_ssid, g_ip_str);
            }
        }
    } else {
        /* 纯 AP 模式 */
        strcpy(g_ip_str, "192.168.4.1");
        g_wifi_status = WIFI_CONNECTED;
        ESP_LOGI(TAG, "AP mode started: SSID=%s, IP=%s", ap_ssid, g_ip_str);
    }
}

void wifi_stop(void)
{
    /* 停止重连定时器 */
    if (g_reconnect_timer) {
        xTimerStop(g_reconnect_timer, 0);
    }
    g_retry_count = 0;

    esp_wifi_disconnect();
    esp_wifi_stop();
    esp_wifi_deinit();
    g_wifi_driver_inited = false;
    g_handlers_registered = false;  // 必须重置，否则下次 init 不会再注册事件处理器
    g_wifi_status = WIFI_DISCONNECTED;
    strcpy(g_ip_str, "0.0.0.0");
    ESP_LOGI(TAG, "WiFi stopped");
}

wifi_status_t wifi_get_status(void)
{
    return g_wifi_status;
}

const char *wifi_status_str(void)
{
    switch (g_wifi_status) {
        case WIFI_DISCONNECTED: return "disconnected";
        case WIFI_CONNECTING:   return "connecting";
        case WIFI_CONNECTED:    return "connected";
        default:                return "unknown";
    }
}

const char *wifi_get_ip_str(void)
{
    return g_ip_str;
}
