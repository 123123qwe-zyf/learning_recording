#ifndef __MSG_H__
#define __MSG_H__

#include <stdbool.h>
#include <stddef.h>

typedef enum {
    MSG_MODE_NORMAL = 0,
    MSG_MODE_STREAM,
    MSG_MODE_SLEEP,
    MSG_MODE_UNKNOWN
} msg_mode_t;// 消息模式枚举

msg_mode_t msg_parse_mode(const char *query_str);
int msg_build_status(char *buf, size_t buf_len, int light, const char *mode,
                     const char *wifi, bool sleeping);// 构建状态字符串

#endif /* __MSG_H__ */
