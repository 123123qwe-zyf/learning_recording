#include "msg.h"
#include <string.h>
#include <stdio.h>

msg_mode_t msg_parse_mode(const char *query_str)// 解析查询字符串中的模式参数
{
    if (!query_str) return MSG_MODE_UNKNOWN;// 查询字符串为空，返回未知模式

    // 查找 "set=" 参数
    const char *key = "set=";// 模式参数键名
    const char *pos = strstr(query_str, key);
    if (!pos) return MSG_MODE_UNKNOWN;// 未找到模式参数，返回未知模式
    pos += strlen(key);// 跳过键名

    char value[16] = {0};
    int i = 0;
    while (*pos && *pos != '&' && i < (int)sizeof(value) - 1) {// 读取模式参数值
        value[i++] = *pos++;
    }
    value[i] = '\0';

    if (strcmp(value, "normal") == 0) return MSG_MODE_NORMAL;// 正常模式
    if (strcmp(value, "stream") == 0) return MSG_MODE_STREAM;// 流式模式
    if (strcmp(value, "sleep") == 0)  return MSG_MODE_SLEEP;// 休眠模式
    return MSG_MODE_UNKNOWN;
}

int msg_build_status(char *buf, size_t buf_len, int light, const char *mode,
                     const char *wifi, bool sleeping)// 构建状态字符串
{
    return snprintf(buf, buf_len,
        "{\"light\":%d,\"mode\":\"%s\",\"wifi\":\"%s\",\"sleep\":%s}",
        light, mode, wifi, sleeping ? "true" : "false");// 构建状态字符串
}
