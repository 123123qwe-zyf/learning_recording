#include <stdio.h>
#include <string.h>

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_sleep.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "app_config.h"
#include "adc.h"
#include "oled.h"
#include "sd.h"
#include "sensor.h"
#include "power.h"
#include "storage.h"
#include "wifi.h"
#include "tcp.h"

#define TAG "MAIN"

static void oled_refresh(int light_val)// 刷新 OLED 显示
{
    oled_update(light_val, power_mode_str(), wifi_status_str(), wifi_get_ip_str(), power_is_sleeping());
}

static void normal_loop(void)// 正常模式循环
{
    ESP_LOGI(TAG, "Entering normal loop");

    wifi_init(WIFI_WORK_MODE, WIFI_STA_SSID, WIFI_STA_PASSWORD,
              WIFI_AP_SSID, WIFI_AP_PASSWORD);// 初始化 WiFi
    tcp_start();// 启动 TCP 服务器
    oled_refresh(sensor_read());// 刷新 OLED 显示

    http_server_start();// 启动 HTTP 服务器
    oled_refresh(sensor_read());

    while (1) {
        work_mode_t mode = power_get_mode();// 获取当前工作模式

        // 模式切换处理
        if (mode == MODE_SLEEP) {
            ESP_LOGI(TAG, "Sleep mode requested via HTTP");
            http_server_stop();// 停止 HTTP 服务器
            wifi_stop();// 停止 WiFi
            oled_refresh(sensor_read());
            return; // 退出，进入 sleep_loop
        }

        // 每秒采样光敏
        int light = sensor_read();// 读取光敏值
        oled_refresh(light);// 刷新 OLED 显示

        // 记录 CSV 日志到片内 Flash
        char log_line[64];
        snprintf(log_line, sizeof(log_line),
                 "%lld,sample,%d\n", esp_timer_get_time() / 1000, light);
        sd_write_append("/sdcard/log.csv", log_line);
        sd_check_rotate_log();

        // 检查是否需要休眠（光线暗）
        if (light >= 0 && light < LIGHT_THRESHOLD) {
            ESP_LOGI(TAG, "Light %d < threshold %d, entering sleep", light, LIGHT_THRESHOLD);
            http_server_stop();
            wifi_stop();
            power_set_mode(MODE_SLEEP);
            oled_refresh(light);
            return;
        }

        vTaskDelay(pdMS_TO_TICKS(SAMPLE_INTERVAL_MS));// 等待 1 秒
    }
}

static void sleep_loop(void)// 休眠模式循环
{
    ESP_LOGI(TAG, "Entering sleep loop");

    while (1) {
        work_mode_t mode = power_get_mode();

        // 如果 HTTP 命令切换回 normal/stream，重新启动 WiFi
        if (mode == MODE_NORMAL || mode == MODE_STREAM) {
            ESP_LOGI(TAG, "Wake-up: mode set to %s", power_mode_str());
            return; // 退出，回到 normal_loop
        }

        // 进入 light sleep，RTC 定时唤醒
        esp_sleep_enable_timer_wakeup(SLEEP_CHECK_INTERVAL_MS * 1000ULL);// 启用 RTC 定时唤醒
        esp_light_sleep_start();// 启动 light sleep

        // 唤醒后快速检测光敏（使用滤波读取，避免误唤醒）
        int light = sensor_read();
        if (light < 0) continue; // ADC 读取异常，继续休眠

        if (light > LIGHT_THRESHOLD) {
            ESP_LOGI(TAG, "Wake-up: light %d > threshold %d", light, LIGHT_THRESHOLD);
            power_set_mode(MODE_NORMAL);
            return; // 退出，回到 normal_loop
        }

        // 仍暗，继续下一次 sleep
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "=== ESP32-S3 Info Collection System ===");

    // 1. 初始化驱动层
    sensor_init();
    oled_init(OLED_SDA_GPIO, OLED_SCL_GPIO, OLED_I2C_ADDR);

    // 2. 挂载片内 Flash FAT 文件系统，将嵌入式 MP3 复制到 /sdcard/
    sd_card_init();
    storage_copy_mp3_to_flash();

    // 3. 初始化电源管理
    power_init();

    // 4. 初始 OLED 显示
    int init_light = sensor_read();
    oled_refresh(init_light);

    // 5. 判断初始状态：先检测光敏
    if (init_light >= 0 && init_light < LIGHT_THRESHOLD) {
        ESP_LOGI(TAG, "Initial: dark environment, entering sleep");
        power_set_mode(MODE_SLEEP);
        oled_refresh(init_light);
    } else {
        ESP_LOGI(TAG, "Initial: bright environment, normal mode");
        power_set_mode(MODE_NORMAL);
        oled_refresh(init_light);
    }

    // 5. 主状态机
    while (1) {
        work_mode_t mode = power_get_mode();

        if (mode == MODE_SLEEP) {
            sleep_loop();
        } else {
            // MODE_NORMAL or MODE_STREAM
            normal_loop();
        }
    }
}
