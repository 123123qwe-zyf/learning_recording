#include <stdio.h>
#include <math.h>
#ifdef _WIN32
#include <windows.h>
#endif

#define PI 3.1415926
#define Z  10
#define L1 12
#define L2 10
#define RAD(d)      (d*PI/180.0)    //degree->rad
#define DEG(rad)    (rad*180.0/PI)  //rad->degree

//算末端T（x,y,z）
void fk(double j1,double j2,double j3,double*x,double*y,double*z)
{
    double r=L1*cos(j2)+L2*cos(j3);
    *x=r*cos(j1);
    *y=r*sin(j1);
    *z=Z+L1*sin(j2)+L2*sin(j3);
}
int ik(double x,double y,double z,double*j1,double*j2,double*j3,double*Dout)
{
    double R=sqrt(x*x+y*y);
    double D=sqrt(R*R+(z-Z)*(z-Z));
    *Dout=D;
    if (D<fabs(L1-L2)||D>L1+L2)
    {
        return 0;
    }
    *j1=atan2(y,x);
    if (R<1e-9)     *j1=0.0;//R很小，即在z轴

    double alpha=atan2(z-Z,R);
    double cb=(L1*L1+D*D-L2*L2)/(2*L1*D);
    if (cb<0.0) cb=0.0;
    if (cb>1.0) cb=1.0;
    double beta=acos(cb);
    *j2=alpha+beta;
    double re=L1*cos(*j2),ze=Z+L1*sin(*j2);
    *j3=atan2(z-ze,R-re);
    return 1;
}
int main(void)
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
#endif
    int pos[6][3]={
        {12,0,16},{10,10,20},{0,0,20},
        {22,0,10},{25,0,15},{5,5,2}
    };
    int n=10;
    double j[3]={0,0,0};

    for (int i=0;i<6;i++)
    {
        double x=pos[i][0],y=pos[i][1],z=pos[i][2];
        double j1,j2,j3,d;
        printf("====目标点%d: (%g,%g,%g)====\n",i+1,x,y,z);
        if (!ik(x,y,z,&j1,&j2,&j3,&d))
        {
            printf("[不可达] 肩(0,0,10)到目标距离 D = %.2f cm\n", d);
            printf("最大臂展 L1+L2 = %.0f cm，超出 %.2f cm，再怎么伸直都够不到。\n\n", L1+L2, d-(L1+L2));
            continue;
        }
        printf("[可达] D = %.2f cm，落在 [2,22] 内。\n", d);
        if (sqrt(x*x+y*y) < 1e-9)
            printf("(注意：目标在 z 轴上，J1 奇异，此处取 0°)\n");

        //运动过程
        printf("运动过程（%d步）--\n",n);
        for (int k=0;k<=n;k++)
        {
            double t=(double)k/(double)n;
            double a1=j[0]+(j1-j[0])*t;
            double a2=j[1]+(j2-j[1])*t;
            double a3=j[2]+(j3-j[2])*t;
            double tx,ty,tz;
            fk(a1,a2,a3,&tx,&ty,&tz);
            printf("  步%-2d: J1=%7.2f° J2=%7.2f° J3=%7.2f° -> T(%7.2f,%7.2f,%7.2f)\n",
                   k, DEG(a1), DEG(a2), DEG(a3), tx, ty, tz);
        }
        double vx,vy,vz;
        fk(j1,j2,j3,&vx,&vy,&vz);
        printf("-- 最终结果 --\n");
        printf("  J1=%7.2f°  J2=%7.2f°  J3=%7.2f°\n", DEG(j1), DEG(j2), DEG(j3));
        printf("  末端 T = (%7.2f,%7.2f,%7.2f)  (FK反算，应与目标一致)\n\n", vx, vy, vz);
    }
    return 0;
}
